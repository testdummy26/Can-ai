import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"app"))
from detection import normalize_event,detect
class DetectionTests(unittest.TestCase):
 def test_aliases(self):
  e=normalize_event({"@timestamp":"2026-10-30T10:00:00Z","src_ip":"192.0.2.1","username":"alice","event":"login","result":"failed"})
  self.assertEqual((e["source_ip"],e["user"],e["status"]),("192.0.2.1","alice","failed"))
 def test_bruteforce(self):
  rows=[normalize_event({"timestamp":f"2026-10-30T09:0{i}:00Z","source_ip":"192.0.2.5","user":"bob","action":"login","status":"failed"}) for i in range(5)]
  self.assertIn("AUTH-001",{a["rule_id"] for a in detect(rows)})
 def test_success_after_failures(self):
  rows=[normalize_event({"timestamp":f"2026-10-30T09:0{i}:00Z","source_ip":"192.0.2.5","user":"bob","action":"login","status":"failed"}) for i in range(3)]
  rows.append(normalize_event({"timestamp":"2026-10-30T09:04:00Z","source_ip":"192.0.2.5","user":"bob","action":"login","status":"success"}))
  self.assertIn("AUTH-002",{a["rule_id"] for a in detect(rows)})
 def test_privilege_and_web(self):
  rows=[normalize_event({"timestamp":"2026-10-30T09:00:00Z","action":"privilege_escalation"}),normalize_event({"timestamp":"2026-10-30T09:01:00Z","action":"web_request","message":"GET /../../etc/passwd"})]
  self.assertTrue({"PRIV-001","WEB-001"}.issubset({a["rule_id"] for a in detect(rows)}))
 def test_empty(self): self.assertEqual(detect([]),[])
if __name__=="__main__": unittest.main()
