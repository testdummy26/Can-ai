# SentinelDesk
A local-first SOC investigation prototype. Import security logs, normalize telemetry, detect suspicious patterns, and triage alerts.

## Requirements
Python 3.11+. No pip packages, API keys, external services, or database provisioning.

## Fresh GitHub Codespaces deployment
1. Upload the contents of this ZIP to an empty GitHub repository, preserving the hidden `.devcontainer` folder.
2. Create a Codespace. Its post-create command compiles the app and runs tests.
3. Open forwarded port 8000.

If you upload the ZIP after creating the Codespace:
```bash
unzip SentinelDesk-*.zip -d .
chmod +x setup.sh run.sh
./setup.sh
./run.sh
```
Open forwarded port 8000.

## Local run
```bash
chmod +x setup.sh run.sh
./setup.sh
./run.sh
```
Open http://localhost:8000.

## First test
Click **Run sample attack scenario**. Expected rule IDs: AUTH-001, AUTH-002, PRIV-001, WEB-001, NET-001.

## Import formats
JSON array, `{"events":[...]}`, or CSV. Canonical fields: timestamp, source_ip, destination_ip, user, action, status, message, host, destination_port. Common aliases are normalized. Use JSON for complex quoted data.

## API
GET `/api/health`, `/api/dashboard`, `/api/alerts`, `/api/events`.
POST `/api/ingest` with `{"events":[...]}`.
POST `/api/alerts/{id}/status` with `{"status":"open|investigating|resolved"}`.
DELETE `/api/reset`.

## Detection rules
AUTH-001: 5+ failed logins from one IP in 10 minutes.
AUTH-002: successful login after 3+ failures for same user/IP in 15 minutes.
PRIV-001: administrative privilege or role-change indicators.
WEB-001: common web probing / injection strings.
NET-001: selected unusual destination ports.

## Safety and limitations
Defensive log analysis only. No network scanning, payload execution, or external host contact. Detections are heuristic and require analyst validation. Not a production SIEM or incident-response platform. CSV parsing is lightweight; JSON is recommended for complex values.
