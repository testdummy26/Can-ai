import json, os, sqlite3
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from detection import normalize_event,detect

BASE=Path(__file__).resolve().parent.parent
DB_PATH=Path(os.environ.get("SENTINEL_DB",BASE/"data"/"sentinel.db"))
WEB=BASE/"app"
def db():
    DB_PATH.parent.mkdir(parents=True,exist_ok=True); c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,timestamp TEXT,source_ip TEXT,destination_ip TEXT,user TEXT,action TEXT,status TEXT,message TEXT,host TEXT,destination_port INTEGER,raw_json TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY,rule_id TEXT,severity TEXT,title TEXT,description TEXT,evidence_json TEXT,dedupe_key TEXT UNIQUE,status TEXT DEFAULT 'open',created_at TEXT)""")
    c.commit(); return c
def dashboard():
    c=db(); n=c.execute("SELECT COUNT(*) FROM events").fetchone()[0]; a=c.execute("SELECT * FROM alerts ORDER BY id DESC").fetchall()
    counts={s:sum(1 for x in a if x["severity"]==s and x["status"]=="open") for s in ("critical","high","medium","low")}
    ev=c.execute("SELECT id,timestamp,source_ip,user,action,status,host FROM events ORDER BY id DESC LIMIT 12").fetchall(); c.close()
    return {"event_count":n,"alert_count":len(a),"open_by_severity":counts,"alerts":[dict(x) for x in a[:50]],"recent_events":[dict(x) for x in ev]}
def ingest(rows):
    c=db()
    for raw in rows:
        e=normalize_event(raw)
        c.execute("INSERT INTO events(timestamp,source_ip,destination_ip,user,action,status,message,host,destination_port,raw_json) VALUES(?,?,?,?,?,?,?,?,?,?)",
          (e["timestamp"],e["source_ip"],e["destination_ip"],e["user"],e["action"],e["status"],e["message"],e["host"],e["destination_port"],json.dumps(e["raw"])))
    allrows=c.execute("SELECT timestamp,source_ip,destination_ip,user,action,status,message,host,destination_port,raw_json FROM events").fetchall()
    events=[]
    for row in allrows:
        e=dict(row); e["raw"]=json.loads(e.pop("raw_json")); events.append(e)
    found=detect(events)
    for a in found:
        c.execute("INSERT OR IGNORE INTO alerts(rule_id,severity,title,description,evidence_json,dedupe_key,created_at) VALUES(?,?,?,?,?,?,?)",
          (a["rule_id"],a["severity"],a["title"],a["description"],json.dumps(a["evidence"]),a["dedupe_key"],datetime.now(timezone.utc).isoformat()))
    c.commit(); c.close(); return {"ingested":len(rows),"alerts_detected":len(found)}
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def reply(self,obj,status=200):
        b=json.dumps(obj,default=str).encode(); self.send_response(status); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(b))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        path=urlparse(self.path).path
        if path=="/api/health": return self.reply({"status":"ok"})
        if path=="/api/dashboard": return self.reply(dashboard())
        if path in ("/api/alerts","/api/events"):
            c=db(); table="alerts" if path.endswith("alerts") else "events"; rows=c.execute(f"SELECT * FROM {table} ORDER BY id DESC LIMIT 500").fetchall(); c.close(); return self.reply([dict(x) for x in rows])
        assets={"/":("index.html","text/html; charset=utf-8"),"/index.html":("index.html","text/html; charset=utf-8"),"/style.css":("style.css","text/css"),"/app.js":("app.js","text/javascript")}
        if path not in assets: return self.reply({"error":"Not found"},404)
        name,typ=assets[path]; b=(WEB/name).read_bytes(); self.send_response(200); self.send_header("Content-Type",typ); self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_POST(self):
        try:
            n=int(self.headers.get("Content-Length","0"))
            if n<1 or n>5_000_000: return self.reply({"error":"Body must be 1 byte to 5 MB"},413)
            payload=json.loads(self.rfile.read(n)); path=urlparse(self.path).path
            if path=="/api/ingest":
                rows=payload if isinstance(payload,list) else payload.get("events",[])
                if not isinstance(rows,list) or not 1<=len(rows)<=10000 or not all(isinstance(x,dict) for x in rows): raise ValueError("Provide 1 to 10,000 event objects")
                return self.reply(ingest(rows),201)
            if path.startswith("/api/alerts/") and path.endswith("/status"):
                aid=int(path.split("/")[3]); status=payload.get("status")
                if status not in {"open","investigating","resolved"}: raise ValueError("Invalid status")
                c=db(); cur=c.execute("UPDATE alerts SET status=? WHERE id=?",(status,aid)); c.commit(); c.close(); return self.reply({"updated":cur.rowcount==1})
            return self.reply({"error":"Not found"},404)
        except (ValueError,TypeError,json.JSONDecodeError) as e: return self.reply({"error":str(e)},400)
    def do_DELETE(self):
        if urlparse(self.path).path!="/api/reset": return self.reply({"error":"Not found"},404)
        c=db(); c.execute("DELETE FROM events"); c.execute("DELETE FROM alerts"); c.commit(); c.close(); return self.reply({"reset":True})
if __name__=="__main__":
    db().close(); host=os.environ.get("HOST","0.0.0.0"); port=int(os.environ.get("PORT","8000"))
    print(f"SentinelDesk listening on http://{host}:{port}",flush=True); ThreadingHTTPServer((host,port),Handler).serve_forever()
