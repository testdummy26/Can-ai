#!/usr/bin/env bash
set -euo pipefail

# Always run from the repository root, even when invoked inside .devcontainer.
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd -- "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

PYTHON_BIN="${PYTHON_BIN:-python3}"
command -v "$PYTHON_BIN" >/dev/null 2>&1 || { echo "Python 3 is required."; exit 1; }
"$PYTHON_BIN" -c 'import sys; assert sys.version_info >= (3, 11), "Python 3.11+ required"; print(f"Using Python {sys.version.split()[0]}")'

python -m venv .venv
.venv/bin/python -m compileall -q app tests
.venv/bin/python -m unittest discover -s tests -v

echo "HeaderHawk setup checks passed. Run ./run.sh to start the server on port 8000."
