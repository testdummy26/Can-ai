#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON_BIN="${PYTHON_BIN:-python3}"
command -v "$PYTHON_BIN" >/dev/null 2>&1 || { echo "Python 3 is required."; exit 1; }
"$PYTHON_BIN" -c 'import sys; assert sys.version_info >= (3, 11), "Python 3.11+ required (Python 3.10 reached end of life in October 2026)"'
echo "[1/3] Creating isolated Python environment..."
"$PYTHON_BIN" -m venv .venv
echo "[2/3] Checking application syntax..."
.venv/bin/python -m compileall -q app tests
echo "[3/3] Running automated tests..."
.venv/bin/python -m unittest discover -s tests -v
echo
echo "Setup complete. Starting HeaderHawk on 0.0.0.0:8000..."
exec .venv/bin/python app/server.py
