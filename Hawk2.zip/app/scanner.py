"""Safe, dependency-free website security checks."""
from __future__ import annotations

import http.client
import ipaddress
import socket
import ssl
from datetime import datetime, timezone
from urllib.parse import urljoin, urlsplit, urlunsplit

TIMEOUT = 8
MAX_REDIRECTS = 8
USER_AGENT = "HeaderHawk/1.0 (local website security inspector)"


class ScanError(Exception):
    """A safe, user-displayable scan error."""


def _validate_url(raw: str) -> tuple[str, str, int, str]:
    if not isinstance(raw, str) or not raw.strip() or len(raw) > 2048:
        raise ScanError("Enter a valid website URL (maximum 2,048 characters).")
    raw = raw.strip()
    if "://" not in raw:
        raw = "https://" + raw
    parsed = urlsplit(raw)
    scheme = parsed.scheme.lower()
    if scheme not in {"http", "https"}:
        raise ScanError("Only http:// and https:// URLs are supported.")
    if not parsed.hostname or parsed.username or parsed.password:
        raise ScanError("The URL must have a hostname and must not contain credentials.")
    host = parsed.hostname.rstrip(".").encode("idna").decode("ascii")
    if host.lower() == "localhost" or host.lower().endswith(".localhost"):
        raise ScanError("Localhost and local network destinations are not allowed.")
    try:
        port = parsed.port or (443 if scheme == "https" else 80)
    except ValueError as exc:
        raise ScanError("The URL contains an invalid port.") from exc
    if not 1 <= port <= 65535:
        raise ScanError("The URL contains an invalid port.")
    path = urlunsplit(("", "", parsed.path or "/", parsed.query, ""))
    return scheme, host, port, path


def _resolve_public(host: str, port: int) -> list[str]:
    try:
        records = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise ScanError(f"DNS lookup failed for {host}.") from exc
    addresses = sorted({item[4][0] for item in records})
    if not addresses:
        raise ScanError(f"No IP addresses were found for {host}.")
    for address in addresses:
        ip = ipaddress.ip_address(address.split("%", 1)[0])
        if not ip.is_global:
            raise ScanError("The destination resolves to a private, reserved, or otherwise non-public IP address. Scan blocked.")
    return addresses


class _PinnedHTTPSConnection(http.client.HTTPSConnection):
    """Connect to a validated IP while preserving hostname-based TLS verification/SNI."""
    def __init__(self, hostname: str, address: str, port: int):
        super().__init__(hostname, port=port, timeout=TIMEOUT, context=ssl.create_default_context())
        self._address = address

    def connect(self):
        sock = socket.create_connection((self._address, self.port), self.timeout)
        self.sock = self._context.wrap_socket(sock, server_hostname=self.host)


def _request_once(scheme: str, host: str, port: int, path: str, address: str):
    headers = {"User-Agent": USER_AGENT, "Accept": "text/html,*/*;q=0.8", "Connection": "close", "Host": host}
    conn: http.client.HTTPConnection
    if scheme == "https":
        conn = _PinnedHTTPSConnection(host, address, port)
    else:
        conn = http.client.HTTPConnection(address, port=port, timeout=TIMEOUT)
    try:
        conn.request("GET", path, headers=headers)
        response = conn.getresponse()
        result = {"status": response.status, "reason": response.reason, "headers": {k.lower(): v for k, v in response.getheaders()}}
        if scheme == "https" and conn.sock:
            cert = conn.sock.getpeercert()
            result["certificate"] = cert
        return result
    finally:
        conn.close()


def _cert_summary(cert: dict | None) -> dict | None:
    if not cert:
        return None
    not_after = cert.get("notAfter")
    expiry = None
    days = None
    if not_after:
        try:
            parsed = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
            expiry = parsed.isoformat()
            days = (parsed - datetime.now(timezone.utc)).days
        except ValueError:
            pass
    issuer = dict(x[0] for x in cert.get("issuer", []))
    subject = dict(x[0] for x in cert.get("subject", []))
    sans = [value for kind, value in cert.get("subjectAltName", []) if kind == "DNS"]
    return {"subject": subject.get("commonName", "Unknown"), "issuer": issuer.get("commonName", issuer.get("organizationName", "Unknown")), "expires_at": expiry, "days_remaining": days, "dns_names": sans[:12]}


def scan_url(raw_url: str) -> dict:
    scheme, host, port, path = _validate_url(raw_url)
    default_port = 443 if scheme == "https" else 80
    display_host = f"[{host}]" if ":" in host else host
    netloc = display_host if port == default_port else f"{display_host}:{port}"
    original = urlunsplit((scheme, netloc, path, "", ""))
    redirects = []
    current = original
    final = None
    for hop in range(MAX_REDIRECTS + 1):
        scheme, host, port, path = _validate_url(current)
        addresses = _resolve_public(host, port)
        try:
            response = _request_once(scheme, host, port, path, addresses[0])
        except (OSError, ssl.SSLError, http.client.HTTPException) as exc:
            raise ScanError(f"Could not connect securely to {host}: {type(exc).__name__}.") from exc
        location = response["headers"].get("location")
        if response["status"] in {301, 302, 303, 307, 308} and location:
            next_url = urljoin(current, location)
            _validate_url(next_url)
            redirects.append({"status": response["status"], "from": current, "to": next_url})
            current = next_url
            continue
        final = {"url": current, "scheme": scheme, "host": host, "status": response["status"], "reason": response["reason"], "headers": response["headers"], "certificate": _cert_summary(response.get("certificate")), "resolved_ips": addresses}
        break
    if final is None:
        raise ScanError(f"The site exceeded the {MAX_REDIRECTS}-redirect limit.")

    h = final["headers"]
    checks = [
        ("Strict-Transport-Security", "strict-transport-security", final["scheme"] == "https", "Enforces HTTPS in supporting browsers."),
        ("Content-Security-Policy", "content-security-policy", True, "Restricts which sources can load scripts, styles, and other content."),
        ("X-Content-Type-Options", "x-content-type-options", True, "Helps prevent MIME-type sniffing."),
        ("Frame protection", "x-frame-options", True, "X-Frame-Options or CSP frame-ancestors helps prevent clickjacking."),
        ("Referrer-Policy", "referrer-policy", True, "Controls how much referrer information browsers send."),
        ("Permissions-Policy", "permissions-policy", True, "Restricts browser features such as camera and geolocation."),
    ]
    findings = []
    passed = 0
    for label, key, applicable, explanation in checks:
        if not applicable:
            findings.append({"name": label, "status": "not_applicable", "detail": "HTTPS is not enabled, so HSTS cannot be evaluated."})
            continue
        present = key in h or (key == "x-frame-options" and "frame-ancestors" in h.get("content-security-policy", "").lower())
        if present:
            passed += 1
            findings.append({"name": label, "status": "present", "detail": explanation, "value": h.get(key, "Protected by CSP frame-ancestors")})
        else:
            findings.append({"name": label, "status": "missing", "detail": explanation})
    applicable_count = sum(1 for item in findings if item["status"] != "not_applicable")
    score = round((passed / applicable_count) * 100) if applicable_count else 0
    return {"target": original, "final_url": final["url"], "http": {"status": final["status"], "reason": final["reason"]}, "resolved_ips": final["resolved_ips"], "redirects": redirects, "tls": {"enabled": final["scheme"] == "https", "certificate": final["certificate"]}, "security_score": score, "security_headers": findings, "checked_at": datetime.now(timezone.utc).isoformat(), "disclaimer": "This is a lightweight configuration check, not a penetration test or a guarantee of security. Results reflect the response visible from this environment."}
