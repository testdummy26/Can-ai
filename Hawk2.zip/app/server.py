from __future__ import annotations
import json
import os
import time
from collections import defaultdict, deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from scanner import ScanError, scan_url

ROOT = Path(__file__).resolve().parent
INDEX = ROOT / "index.html"
RATE = defaultdict(deque)

class Handler(BaseHTTPRequestHandler):
    server_version = "HeaderHawk/1.0"

    def _send(self, status: int, body: bytes, content_type: str):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        route = urlparse(self.path).path
        assets = {"/style.css": (ROOT / "style.css", "text/css; charset=utf-8"),
                  "/app.js": (ROOT / "app.js", "text/javascript; charset=utf-8")}
        if route == "/":
            self._send(200, INDEX.read_bytes(), "text/html; charset=utf-8")
        elif route == "/health":
            self._send(200, b'{"status":"ok","app":"HeaderHawk"}', "application/json")
        elif route in assets:
            path, content_type = assets[route]
            self._send(200, path.read_bytes(), content_type)
        else:
            self._send(404, b"Not found", "text/plain; charset=utf-8")

    def do_POST(self):
        if urlparse(self.path).path != "/api/scan":
            self._send(404, b'{"error":"Not found"}', "application/json")
            return
        now = time.time()
        bucket = RATE[self.client_address[0]]
        while bucket and bucket[0] < now - 60:
            bucket.popleft()
        if len(bucket) >= 10:
            self._send(429, b'{"error":"Rate limit reached. Try again in a minute."}', "application/json")
            return
        bucket.append(now)
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0 or length > 4096:
            self._send(400, b'{"error":"Request body must be between 1 and 4,096 bytes."}', "application/json")
            return
        try:
            payload = json.loads(self.rfile.read(length))
            result = scan_url(payload.get("url", ""))
            body = json.dumps(result).encode()
            self._send(200, body, "application/json; charset=utf-8")
        except (json.JSONDecodeError, AttributeError, TypeError):
            self._send(400, b'{"error":"Send JSON with a url field."}', "application/json")
        except ScanError as exc:
            body = json.dumps({"error": str(exc)}).encode()
            self._send(400, body, "application/json; charset=utf-8")
        except Exception:
            self.log_error("Unexpected scan error")
            self._send(500, b'{"error":"Unexpected scan error. Check the server log."}', "application/json")

    def log_message(self, fmt, *args):
        print("[%s] %s" % (self.log_date_time_string(), fmt % args))


def main():
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8000"))
    server = ThreadingHTTPServer((host, port), Handler)
    print(f"\n  HeaderHawk is running at http://127.0.0.1:{port}")
    print(f"  Listening on {host}:{port}. Press Ctrl+C to stop.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down HeaderHawk...")
    finally:
        server.server_close()

if __name__ == "__main__":
    main()
