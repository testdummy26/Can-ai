const $ = (id) => document.getElementById(id);
let latestReport = null;
const form = $('scan-form');
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const url = $('url').value.trim();
  if (!url) return;
  $('scan-btn').disabled = true;
  $('scan-btn').textContent = 'Inspecting…';
  $('welcome').classList.add('hidden');
  $('results').classList.add('hidden');
  $('loading').classList.remove('hidden');
  $('loading-text').textContent = 'Resolving public DNS and checking the website…';
  try {
    const response = await fetch('/api/scan', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url})});
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Inspection failed.');
    latestReport = data;
    render(data);
  } catch (error) {
    $('loading').classList.add('hidden');
    $('welcome').classList.remove('hidden');
    alert(error.message || 'Could not complete inspection.');
  } finally {
    $('scan-btn').disabled = false;
    $('scan-btn').innerHTML = 'Inspect site <b>↗</b>';
  }
});
function setText(id, value) { $(id).textContent = value ?? 'Not available'; }
function render(data) {
  $('loading').classList.add('hidden'); $('results').classList.remove('hidden');
  const hostname = (() => {try{return new URL(data.final_url).hostname;}catch{return data.final_url;}})();
  setText('result-host', hostname); setText('result-url', data.target);
  setText('score', data.security_score);
  const score = data.security_score;
  setText('score-title', score >= 80 ? 'Strong header coverage' : score >= 50 ? 'Room for improvement' : 'Several gaps found');
  setText('score-copy', `${data.security_headers.filter(x=>x.status==='present').length} of ${data.security_headers.filter(x=>x.status!=='not_applicable').length} checks passed`);
  $('score-ring').style.borderColor = score >= 80 ? '#67d7a2' : score >= 50 ? '#f3bd67' : '#ff777e';
  setText('http-status', `${data.http.status}`); setText('http-reason', data.http.reason);
  setText('tls-status', data.tls.enabled ? 'Enabled' : 'Not enabled');
  setText('tls-expiry', data.tls.certificate?.days_remaining == null ? 'No certificate details' : `${data.tls.certificate.days_remaining} days remaining`);
  $('headers-list').replaceChildren();
  for (const item of data.security_headers) {
    const row=document.createElement('div');row.className='finding';
    const dot=document.createElement('i');dot.className=`dot ${item.status==='present'?'present':'missing'}`;
    const content=document.createElement('div');const title=document.createElement('strong');title.textContent=item.name;const desc=document.createElement('p');desc.textContent=item.detail+(item.value?` Value: ${item.value}`:'');content.append(title,desc);
    const status=document.createElement('span');status.className=`status ${item.status==='present'?'':'missing'}`;status.textContent=item.status==='present'?'PRESENT':item.status==='not_applicable'?'N/A':'MISSING';row.append(dot,content,status);$('headers-list').append(row);
  }
  setText('ips', data.resolved_ips.join(', ')); setText('final-url', data.final_url); setText('redirect-count', data.redirects.length);
  $('redirect-list').replaceChildren();
  data.redirects.forEach((r,i)=>{const line=document.createElement('div');line.textContent=`${i+1}. ${r.status}  ${r.from} → ${r.to}`;$('redirect-list').append(line);});
  const cert=data.tls.certificate;
  setText('cert-subject',cert?.subject);setText('cert-issuer',cert?.issuer);setText('cert-expiry',cert?.expires_at?new Date(cert.expires_at).toLocaleString():null);setText('cert-names',cert?.dns_names?.join(', '));
  setText('disclaimer',data.disclaimer);setText('timestamp',`Checked ${new Date(data.checked_at).toLocaleString()}`);
  $('results').scrollIntoView({behavior:'smooth',block:'start'});
}
$('export-btn').addEventListener('click',()=>{
  if(!latestReport)return;
  const blob=new Blob([JSON.stringify(latestReport,null,2)],{type:'application/json'});
  const link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download='headerhawk-report.json';link.click();URL.revokeObjectURL(link.href);
});
