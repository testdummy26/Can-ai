import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
import unittest
from scanner import ScanError, _validate_url, _resolve_public

class URLValidationTests(unittest.TestCase):
    def test_adds_https_by_default(self):
        self.assertEqual(_validate_url("example.com")[0], "https")

    def test_rejects_non_http_scheme(self):
        with self.assertRaises(ScanError):
            _validate_url("file:///etc/passwd")

    def test_rejects_credentials(self):
        with self.assertRaises(ScanError):
            _validate_url("https://user:pass@example.com")

    def test_rejects_localhost(self):
        with self.assertRaises(ScanError):
            _validate_url("http://localhost:8000")

    def test_rejects_private_resolved_ip(self):
        from unittest.mock import patch
        fake = [(None, None, None, None, ("192.168.1.10", 443))]
        with patch("scanner.socket.getaddrinfo", return_value=fake):
            with self.assertRaises(ScanError):
                _resolve_public("example.test", 443)

if __name__ == "__main__":
    unittest.main(verbosity=2)
