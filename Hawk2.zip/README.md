# HeaderHawk

A dependency-free, local-first website configuration inspector. It checks public DNS resolution, HTTP response status, redirects, TLS certificate details, and six common browser security-header protections.

## Requirements

- Python 3.11 or newer (Codespaces image uses Python 3.14)
- Outbound network access to the public website being inspected
- No API keys, database, Node.js, or third-party Python packages

## GitHub Codespaces quick start

**Fastest route:** create a new, empty GitHub repository, upload the files from this ZIP into the repository root (including the hidden `.devcontainer` folder), then create a Codespace. Codespaces will detect the included Python dev-container configuration and run the syntax checks and tests during setup.

If you upload the ZIP file itself instead of extracting its contents on GitHub:

1. Create a Codespace for the empty repository.
2. In the Codespaces terminal, extract the ZIP into the repository root:

   ```bash
   unzip headerhawk.zip -d .
   ```

3. Start the app with the one-command setup:

   ```bash
   chmod +x setup.sh run.sh
   ./setup.sh
   ```

   This creates the virtual environment, compiles the application, runs all tests, and starts the server.
4. Codespaces normally detects port **8000** automatically. If it does not, open the **Ports** tab and forward port 8000, then open it in the browser.

If you extracted the ZIP after the Codespace was already created and want the dev-container settings applied, use **Codespaces: Rebuild Container** from the command palette. This is optional; `./setup.sh` works without rebuilding.

## Run it again

After setup has completed once, start the app with:

```bash
./run.sh
```

Stop it with `Ctrl+C`.

## Configuration

Defaults: `HOST=0.0.0.0`, `PORT=8000`. Override with environment variables:

```bash
HOST=127.0.0.1 PORT=8000 ./run.sh
```

Open `http://127.0.0.1:8000` locally.

## Safety model

- Only HTTP and HTTPS URLs are accepted.
- URL credentials, localhost names, private/reserved/non-public IP destinations are blocked.
- DNS is resolved and every returned address must be globally routable. Connections are pinned to the validated IP while preserving TLS hostname verification and SNI.
- Redirects are followed manually, with every hop revalidated and an eight-hop limit.
- Requests have a timeout, a 10-scans-per-minute per-client rate limit, and a bounded request body.
- The Codespaces port is configured as **private**.

Only inspect websites you own or are authorized to assess. This is a lightweight passive configuration check, not a penetration test, vulnerability scanner, or guarantee of security. Network filtering, DNS behavior, and site responses may differ between environments.

## Project layout

```text
headerhawk/
├── .devcontainer/
│   ├── devcontainer.json
│   └── setup-codespaces.sh
├── app/
│   ├── app.js
│   ├── index.html
│   ├── scanner.py
│   ├── server.py
│   └── style.css
├── tests/
│   └── test_scanner.py
├── .gitignore
├── README.md
├── run.sh
└── setup.sh
```
