#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
python3 - <<'PY'
import sys
if sys.version_info < (3,11): raise SystemExit("Python 3.11+ required")
print("Python",sys.version.split()[0])
PY
python3 -m compileall -q app tests
python3 -m unittest discover -s tests -v
echo "Setup complete. Run ./run.sh"
