"""Local heuristic detections for common IT and DNP3 telemetry."""
from collections import defaultdict
from datetime import datetime, timedelta, timezone


def parse_time(value):
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except (ValueError, TypeError):
        return None


def normalize_event(raw):
    """Normalize common aliases while retaining the untouched original object."""
    if not isinstance(raw, dict):
        raise ValueError("Each event must be a JSON object")
    r = {str(k).strip().lower(): v for k, v in raw.items()}

    def pick(*keys, default=""):
        return next((r[k] for k in keys if r.get(k) not in (None, "")), default)

    try:
        port = int(pick("destination_port", "dst_port", "responderport", "port", default=0) or 0)
    except (ValueError, TypeError):
        port = 0
    event_type = pick("action", "event", "event_type", "type", default="unknown")
    device = pick("host", "hostname", "computer", "device_id", "device")
    source = pick("source_ip", "src_ip", "client_ip", "initiatorip", "ip")
    return {
        "timestamp": str(pick("timestamp", "@timestamp", "time", "date")),
        "source_ip": str(source),
        "destination_ip": str(pick("destination_ip", "dst_ip", "server_ip", "responderip")),
        "user": str(pick("user", "username", "account")),
        "action": str(event_type).lower().replace(" ", "_"),
        "status": str(pick("status", "result", "outcome", "severity")).lower(),
        "message": str(pick("message", "details", "description")),
        "host": str(device),
        "destination_port": port,
        "raw": raw,
    }


def detect(events):
    alerts = []
    by_ip = defaultdict(list)
    dnp3_groups = defaultdict(list)

    def emit(rule, sev, title, desc, evidence, key):
        alerts.append({"rule_id": rule, "severity": sev, "title": title,
                       "description": desc, "evidence": evidence[:30], "dedupe_key": key})

    for e in events:
        if e["source_ip"]:
            by_ip[e["source_ip"]].append(e)
        raw = e.get("raw", {})
        raw_l = {str(k).lower(): v for k, v in raw.items()} if isinstance(raw, dict) else {}
        protocol = str(raw_l.get("protocol", "")).lower()
        event_type = str(raw_l.get("event_type", e["action"])).lower()
        if protocol == "dnp3" or event_type in {"unauthorized_control", "spoofed_status", "malformed_command", "flood"}:
            dnp3_groups[(event_type, e["host"] or "unknown")].append(e)

    failed = {"failed", "failure", "denied", "invalid"}
    success = {"success", "successful", "ok", "accepted"}
    for ip, rows in by_ip.items():
        bad = [e for e in rows if ("login" in e["action"] or "auth" in e["action"])
               and (e["status"] in failed or "fail" in e["action"])]
        bad.sort(key=lambda e: parse_time(e["timestamp"]) or datetime.max.replace(tzinfo=timezone.utc))
        for e in bad:
            t = parse_time(e["timestamp"])
            if t and sum(1 for x in bad if parse_time(x["timestamp"]) and t <= parse_time(x["timestamp"]) <= t + timedelta(minutes=10)) >= 5:
                emit("AUTH-001", "high", "Possible brute-force login activity",
                     f"At least 5 failed authentications from {ip} within 10 minutes.", bad, f"AUTH-001:{ip}")
                break
        for e in rows:
            if not (("login" in e["action"] or "auth" in e["action"]) and e["status"] in success):
                continue
            t = parse_time(e["timestamp"])
            if not t:
                continue
            prior = [x for x in rows if x["user"] == e["user"] and (x["status"] in failed or "fail" in x["action"])
                     and parse_time(x["timestamp"]) and timedelta(0) <= t - parse_time(x["timestamp"]) <= timedelta(minutes=15)]
            if len(prior) >= 3:
                emit("AUTH-002", "critical", "Successful login after repeated failures",
                     f"{e['user'] or 'Unknown account'} authenticated from {ip} after {len(prior)} failures.",
                     prior + [e], f"AUTH-002:{ip}:{e['user']}")

    for e in events:
        text = " ".join((e["action"], e["status"], e["message"])).lower()
        if any(x in text for x in ("privilege_escalation", "privilege elevated", "added_to_admin", "sudo granted", "role changed to admin")):
            emit("PRIV-001", "high", "Possible privilege escalation",
                 "An event indicates an administrative privilege or role change.", [e],
                 f"PRIV-001:{e['user']}:{e['timestamp']}")
        indicators = [x for x in ("../", "%2e%2e", "union select", "<script", "/etc/passwd", "cmd=", "powershell -enc") if x in text]
        if indicators:
            emit("WEB-001", "medium", "Suspicious request pattern",
                 "Event text contains common web probing or injection indicators.", [e],
                 f"WEB-001:{e['source_ip']}:{e['timestamp']}")
        if e["destination_port"] in {4444, 5555, 6667, 1337, 31337}:
            emit("NET-001", "medium", "Connection to unusual destination port",
                 f"Observed destination port {e['destination_port']}; validate expected use.", [e],
                 f"NET-001:{e['source_ip']}:{e['destination_port']}:{e['timestamp']}")

    # Explicit DNP3 attack labels are treated as telemetry indicators, not generic severity labels.
    # Ordinary warning/critical severities alone never create an alert.
    dnp3_rules = {
        "unauthorized_control": ("ICS-001", "critical", "Unauthorized DNP3 control operation", "DNP3 telemetry explicitly labels a control operation as unauthorized."),
        "malformed_command": ("ICS-002", "high", "Malformed DNP3 command", "DNP3 telemetry explicitly labels a command as malformed."),
        "spoofed_status": ("ICS-003", "high", "Potentially spoofed DNP3 status", "DNP3 telemetry explicitly labels a status event as spoofed."),
        "flood": ("ICS-004", "high", "DNP3 event flood indicator", "DNP3 telemetry explicitly labels this activity as a flood."),
    }
    for (event_type, device), rows in dnp3_groups.items():
        if event_type not in dnp3_rules:
            continue
        rule, sev, title, desc = dnp3_rules[event_type]
        rows.sort(key=lambda x: x.get("timestamp", ""))
        sources = sorted({x["source_ip"] for x in rows if x["source_ip"]})
        source_summary = ", ".join(sources[:8]) + (f" and {len(sources)-8} more" if len(sources) > 8 else "")
        emit(rule, sev, title, f"{desc} Device: {device}; matching records: {len(rows)}; source IPs: {source_summary or 'not provided'}.",
             rows, f"{rule}:{device}")

    unique = {}
    for alert in alerts:
        unique.setdefault(alert["dedupe_key"], alert)
    return list(unique.values())
