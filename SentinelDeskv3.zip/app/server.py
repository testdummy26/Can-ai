"""SentinelDesk local-first HTTP and SQLite service."""
import csv
import io
import json
import os
import sqlite3
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse
from detection import normalize_event, detect

BASE = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.environ.get("SENTINEL_DB", BASE / "data" / "sentinel.db"))
WEB = BASE / "app"
MAX_BODY = 25 * 1024 * 1024
MAX_EVENTS = 50000


def db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB_PATH, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("""CREATE TABLE IF NOT EXISTS events(
        id INTEGER PRIMARY KEY, timestamp TEXT, source_ip TEXT, destination_ip TEXT,
        user TEXT, action TEXT, status TEXT, message TEXT, host TEXT,
        destination_port INTEGER, raw_json TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS alerts(
        id INTEGER PRIMARY KEY, rule_id TEXT, severity TEXT, title TEXT,
        description TEXT, evidence_json TEXT, dedupe_key TEXT UNIQUE,
        status TEXT DEFAULT 'open', created_at TEXT, occurred_at TEXT)""")
    cols = {r[1] for r in c.execute("PRAGMA table_info(alerts)")}
    if "occurred_at" not in cols:
        c.execute("ALTER TABLE alerts ADD COLUMN occurred_at TEXT")
    c.commit()
    return c


def _event_total(c):
    return c.execute("SELECT COUNT(*) FROM events").fetchone()[0]


def dashboard():
    c = db()
    n = _event_total(c)
    all_alerts = c.execute("SELECT * FROM alerts ORDER BY id DESC").fetchall()
    counts = {s: sum(1 for a in all_alerts if a["severity"] == s and a["status"] == "open")
              for s in ("critical", "high", "medium", "low")}
    ev = c.execute("SELECT id,timestamp,source_ip,user,action,status,host FROM events ORDER BY id DESC LIMIT 12").fetchall()
    c.close()
    return {"event_count": n, "alert_count": len(all_alerts), "open_by_severity": counts,
            "alerts": [dict(x) for x in all_alerts], "recent_events": [dict(x) for x in ev]}


def ingest(rows):
    if not isinstance(rows, list) or not rows:
        raise ValueError("Provide at least one event")
    if len(rows) > MAX_EVENTS:
        raise ValueError(f"Import exceeds the {MAX_EVENTS:,}-event request limit; split the file into smaller imports")
    normalized = [normalize_event(raw) for raw in rows]
    c = db()
    try:
        c.execute("BEGIN IMMEDIATE")
        c.executemany("""INSERT INTO events(timestamp,source_ip,destination_ip,user,action,status,message,host,destination_port,raw_json)
            VALUES(?,?,?,?,?,?,?,?,?,?)""",
            [(e["timestamp"], e["source_ip"], e["destination_ip"], e["user"], e["action"], e["status"],
              e["message"], e["host"], e["destination_port"], json.dumps(e["raw"], ensure_ascii=False)) for e in normalized])
        allrows = c.execute("SELECT timestamp,source_ip,destination_ip,user,action,status,message,host,destination_port,raw_json FROM events").fetchall()
        events = []
        for row in allrows:
            e = dict(row)
            e["raw"] = json.loads(e.pop("raw_json"))
            events.append(e)
        found = detect(events)
        created_at = datetime.now(timezone.utc).isoformat()
        inserted_alerts = 0
        for a in found:
            evidence = a["evidence"]
            occurred = max((str(x.get("timestamp", "")) for x in evidence if x.get("timestamp")), default="")
            cur = c.execute("""INSERT OR IGNORE INTO alerts(rule_id,severity,title,description,evidence_json,dedupe_key,created_at,occurred_at)
                VALUES(?,?,?,?,?,?,?,?)""",
                (a["rule_id"], a["severity"], a["title"], a["description"],
                 json.dumps(evidence, ensure_ascii=False), a["dedupe_key"], created_at, occurred))
            inserted_alerts += max(0, cur.rowcount)
        c.commit()
        return {"ingested": len(rows), "total_events": _event_total(c), "alerts_detected": len(found),
                "new_alerts": inserted_alerts, "request_limit": MAX_EVENTS}
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def reply(self, obj, status=200):
        body = json.dumps(obj, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/api/health":
            c = db(); count = _event_total(c); c.close()
            return self.reply({"status": "ok", "event_count": count})
        if path == "/api/dashboard":
            return self.reply(dashboard())
        if path in ("/api/alerts", "/api/events"):
            table = "alerts" if path.endswith("alerts") else "events"
            params = parse_qs(parsed.query)
            try:
                limit = min(MAX_EVENTS, max(1, int(params.get("limit", ["1000"])[0])))
                offset = max(0, int(params.get("offset", ["0"])[0]))
            except ValueError:
                return self.reply({"error": "limit and offset must be integers"}, 400)
            c = db()
            total = c.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            rows = c.execute(f"SELECT * FROM {table} ORDER BY id DESC LIMIT ? OFFSET ?", (limit, offset)).fetchall()
            c.close()
            return self.reply({"items": [dict(x) for x in rows], "total": total, "limit": limit, "offset": offset})
        assets = {"/": ("index.html", "text/html; charset=utf-8"), "/index.html": ("index.html", "text/html; charset=utf-8"),
                  "/style.css": ("style.css", "text/css; charset=utf-8"), "/app.js": ("app.js", "text/javascript; charset=utf-8")}
        if path not in assets:
            return self.reply({"error": "Not found"}, 404)
        name, content_type = assets[path]
        body = (WEB / name).read_bytes()
        self.send_response(200); self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)

    def do_POST(self):
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size < 1:
                return self.reply({"error": "Request body is empty"}, 400)
            if size > MAX_BODY:
                return self.reply({"error": f"Request exceeds {MAX_BODY // (1024 * 1024)} MB"}, 413)
            payload = json.loads(self.rfile.read(size))
            path = urlparse(self.path).path
            if path == "/api/ingest":
                rows = payload if isinstance(payload, list) else payload.get("events", []) if isinstance(payload, dict) else []
                if not isinstance(rows, list) or not rows or not all(isinstance(x, dict) for x in rows):
                    raise ValueError("Provide a JSON array or {\"events\": [...]} containing event objects")
                return self.reply(ingest(rows), 201)
            if path.startswith("/api/alerts/") and path.endswith("/status"):
                aid = int(path.split("/")[3]); status = payload.get("status")
                if status not in {"open", "investigating", "resolved"}:
                    raise ValueError("Status must be open, investigating, or resolved")
                c = db(); cur = c.execute("UPDATE alerts SET status=? WHERE id=?", (status, aid)); c.commit(); c.close()
                return self.reply({"updated": cur.rowcount == 1})
            return self.reply({"error": "Not found"}, 404)
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            return self.reply({"error": str(exc)}, 400)

    def do_DELETE(self):
        if urlparse(self.path).path != "/api/reset":
            return self.reply({"error": "Not found"}, 404)
        c = db(); c.execute("DELETE FROM events"); c.execute("DELETE FROM alerts"); c.commit(); c.close()
        return self.reply({"reset": True})


if __name__ == "__main__":
    db().close()
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8000"))
    print(f"SentinelDesk listening on http://{host}:{port}", flush=True)
    ThreadingHTTPServer((host, port), Handler).serve_forever()
