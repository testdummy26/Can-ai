import json
import sys
import tempfile
import unittest
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from http.server import ThreadingHTTPServer
from threading import Thread

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))
from detection import normalize_event, detect


class DetectionTests(unittest.TestCase):
    def test_aliases(self):
        e = normalize_event({"@timestamp": "2026-10-30T10:00:00Z", "src_ip": "192.0.2.1", "username": "alice", "event": "login", "result": "failed"})
        self.assertEqual((e["source_ip"], e["user"], e["status"]), ("192.0.2.1", "alice", "failed"))

    def test_bruteforce(self):
        rows = [normalize_event({"timestamp": f"2026-10-30T09:0{i}:00Z", "source_ip": "192.0.2.5", "user": "bob", "action": "login", "status": "failed"}) for i in range(5)]
        self.assertIn("AUTH-001", {a["rule_id"] for a in detect(rows)})

    def test_success_after_failures(self):
        rows = [normalize_event({"timestamp": f"2026-10-30T09:0{i}:00Z", "source_ip": "192.0.2.5", "user": "bob", "action": "login", "status": "failed"}) for i in range(3)]
        rows.append(normalize_event({"timestamp": "2026-10-30T09:04:00Z", "source_ip": "192.0.2.5", "user": "bob", "action": "login", "status": "success"}))
        self.assertIn("AUTH-002", {a["rule_id"] for a in detect(rows)})

    def test_privilege_and_web(self):
        rows = [normalize_event({"timestamp": "2026-10-30T09:00:00Z", "action": "privilege_escalation"}), normalize_event({"timestamp": "2026-10-30T09:01:00Z", "action": "web_request", "message": "GET /../../etc/passwd"})]
        self.assertTrue({"PRIV-001", "WEB-001"}.issubset({a["rule_id"] for a in detect(rows)}))

    def test_dnp3_explicit_labels(self):
        types = ["unauthorized_control", "malformed_command", "spoofed_status", "flood"]
        rows = [normalize_event({"timestamp": f"2025-08-01T08:00:{i:02d}Z", "protocol": "DNP3", "device_id": "PLC-01", "source_ip": "10.0.0.5", "event_type": t, "severity": "critical"}) for i, t in enumerate(types)]
        self.assertEqual({"ICS-001", "ICS-002", "ICS-003", "ICS-004"}, {a["rule_id"] for a in detect(rows)})

    def test_dnp3_warning_severity_alone_is_not_alert(self):
        rows = [normalize_event({"timestamp": "2025-08-01T08:00:00Z", "protocol": "DNP3", "device_id": "PLC-01", "source_ip": "10.0.0.5", "event_type": "analog_input", "severity": "warning"})]
        self.assertEqual([], detect(rows))

    def test_dnp3_groups_and_preserves_evidence(self):
        rows = [normalize_event({"timestamp": f"2025-08-01T08:00:{i:02d}Z", "protocol": "DNP3", "device_id": "PLC-01", "source_ip": "10.0.0.5", "event_type": "unauthorized_control", "index": i, "value": 1}) for i in range(40)]
        alerts = [a for a in detect(rows) if a["rule_id"] == "ICS-001"]
        self.assertEqual(1, len(alerts))
        self.assertEqual(30, len(alerts[0]["evidence"]))
        self.assertIn("index", alerts[0]["evidence"][0]["raw"])

    def test_large_batch_has_no_500_cap(self):
        rows = [normalize_event({"timestamp": "2025-08-01T08:00:00Z", "protocol": "DNP3", "device_id": f"PLC-{i%20}", "source_ip": f"10.0.{i//254}.{i%254+1}", "event_type": "analog_input", "severity": "info"}) for i in range(5001)]
        self.assertEqual(5001, len(rows))
        self.assertEqual([], detect(rows))

    def test_empty(self):
        self.assertEqual([], detect([]))


if __name__ == "__main__":
    unittest.main()
