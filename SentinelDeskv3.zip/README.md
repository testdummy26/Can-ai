# SentinelDesk v3

A local-first SOC investigation prototype. Import security telemetry, preserve source records, detect suspicious patterns, and triage alerts. No third-party packages, API keys, or external services are required.

## Requirements

- Python 3.11 or newer
- A modern browser

## GitHub Codespaces deployment

1. Create an empty GitHub repository.
2. Upload the contents of this ZIP to the repository. Keep the hidden `.devcontainer` folder.
3. Create a Codespace. The post-create setup compiles the Python files and runs the test suite.
4. Open forwarded port **8000** when the server starts.

If the Codespace already exists, upload/extract the ZIP in its terminal and run:

```bash
unzip SentinelDesk-v3-*.zip -d .
chmod +x setup.sh run.sh
./setup.sh
./run.sh
```

Open port 8000 in the Ports tab. The app binds to `0.0.0.0` for Codespaces forwarding.

## Local run

```bash
chmod +x setup.sh run.sh
./setup.sh
./run.sh
```

Then open http://localhost:8000.

## Import support

- JSON array: `[{...}, {...}]`
- JSON object containing an `events` array
- NDJSON / JSON Lines: one JSON event object per line
- CSV with a header row, including quoted fields and commas
- `.log` text files: JSON lines are parsed as records; otherwise each non-empty line is retained as an `unparsed_log_line` event with filename and line number

The browser import limit is 25 MB and 50,000 event records per file. The API accepts up to 25 MB and 50,000 event objects per request. Imports are transactional: if a record is invalid, the batch is rejected rather than silently partially imported. The interface reports imported count, rejected count, and resulting workspace total. There is no 500-event display/export cap.

The original source object is stored in `raw_json` and included in the investigation export. DNP3 fields such as `protocol`, `device_id`, `event_type`, `severity`, `index`, and `value` remain available in the preserved original record. Normalized columns are convenience fields, not a replacement for source data.

## Detection rules

### General security telemetry

- **AUTH-001:** 5 or more failed authentications from one source IP within 10 minutes.
- **AUTH-002:** successful authentication after 3 or more failures for the same user and source IP within 15 minutes.
- **PRIV-001:** privilege escalation / administrative role-change indicators.
- **WEB-001:** common web probing and injection indicators.
- **NET-001:** selected unusual destination ports.

### DNP3 / ICS telemetry

- **ICS-001:** explicitly labeled `unauthorized_control` event (critical).
- **ICS-002:** explicitly labeled `malformed_command` event (high).
- **ICS-003:** explicitly labeled `spoofed_status` event (high).
- **ICS-004:** explicitly labeled `flood` event (high).

DNP3 alerts are grouped by source and device, with up to 30 representative evidence records per alert. A generic `warning` or `critical` severity does not independently create an alert. The event type / explicit indicator is required. These are dataset-label detections, not proof that an operational device was compromised.

## API

- `GET /api/health`
- `GET /api/dashboard`
- `GET /api/alerts?limit=1000&offset=0`
- `GET /api/events?limit=1000&offset=0`
- `POST /api/ingest` with `{"events":[...]}` or a JSON array
- `POST /api/alerts/{id}/status` with `{"status":"open|investigating|resolved"}`
- `DELETE /api/reset`

List endpoints return `{items, total, limit, offset}`. Clients can page through the entire dataset. JSON and CSV exports fetch every page and verify that the exported count equals the server's reported total before creating the file.

## Data and safety

SQLite data is stored under `data/sentinel.db` by default. Set `SENTINEL_DB` to choose another path. No telemetry is sent to an external service. The app does not scan networks, execute payloads, or contact hosts. Heuristic detections require analyst validation. This is a prototype, not a production SIEM or incident-response platform.
